# train model U_Net/AttU_Net/TransUnet/RWKV_UNet/MissFormer
python main.py --max_epochs 300 --gpu 0 --batch_size 8 --model U_Net --base_dir ./data/camus --dataset_name camus
# inference
python main.py --max_epochs 300 --gpu 0 --batch_size 8 --model U_Net --base_dir ./data/camus --dataset_name camus --just_for_test True
