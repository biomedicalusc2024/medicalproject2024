#!/usr/bin/env python3
"""
修复mamba_ssm兼容性问题的脚本
"""

import subprocess
import sys
import os

def run_command(cmd, description):
    """运行命令并打印结果"""
    print(f"\n{'='*50}")
    print(f"执行: {description}")
    print(f"命令: {cmd}")
    print('='*50)
    
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ 成功!")
            if result.stdout:
                print("输出:", result.stdout)
        else:
            print("❌ 失败!")
            if result.stderr:
                print("错误:", result.stderr)
        return result.returncode == 0
    except Exception as e:
        print(f"❌ 异常: {e}")
        return False

def main():
    print("🔧 开始修复mamba_ssm兼容性问题...")
    
    # 1. 检查当前环境
    print("\n1. 检查当前环境...")
    run_command("python -c 'import torch; print(f\"PyTorch: {torch.__version__}\")'", "检查PyTorch版本")
    run_command("python -c 'import torch; print(f\"CUDA available: {torch.cuda.is_available()}\")'", "检查CUDA可用性")
    
    # 2. 卸载现有的mamba_ssm
    print("\n2. 卸载现有的mamba_ssm...")
    run_command("pip uninstall mamba-ssm -y", "卸载mamba-ssm")
    
    # 3. 清理缓存
    print("\n3. 清理pip缓存...")
    run_command("pip cache purge", "清理pip缓存")
    
    # 4. 重新安装mamba_ssm
    print("\n4. 重新安装mamba_ssm...")
    run_command("pip install mamba-ssm", "安装mamba-ssm")
    
    # 5. 如果还是有问题，尝试从源码安装
    print("\n5. 如果上述方法失败，尝试从源码安装...")
    run_command("pip uninstall mamba-ssm -y", "再次卸载mamba-ssm")
    run_command("pip install causal-conv1d>=1.0.0", "安装依赖")
    run_command("pip install mamba-ssm --no-build-isolation", "从源码安装mamba-ssm")
    
    # 6. 测试安装
    print("\n6. 测试安装...")
    success = run_command("python -c 'from mamba_ssm.ops.selective_scan_interface import selective_scan_fn; print(\"✅ mamba_ssm导入成功!\")'", "测试mamba_ssm导入")
    
    if success:
        print("\n🎉 修复完成! mamba_ssm现在应该可以正常工作了。")
    else:
        print("\n❌ 修复失败。请尝试以下替代方案:")
        print("1. 更新PyTorch到最新版本")
        print("2. 检查CUDA版本兼容性")
        print("3. 考虑使用CPU版本的mamba_ssm")
        print("4. 或者修改模型代码，使用其他替代实现")

if __name__ == "__main__":
    main()
