# U-Bench: A Comprehensive Understanding of U-Net through 100-Variant Benchmarking

We expand U-Bench on new modality - Echocardiography.

### Quick Start 🤩🤩🤩

| Model Zoo                                                    | Data Zoo                                                     |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| [Code](https://github.com/FengheTan9/U-Bench) \| [Weights (Hugging Face)](https://huggingface.co/FengheTan9/U-Bench) | [Data (Hugging Face)](https://huggingface.co/datasets/FengheTan9/U-Bench) |

#### 1. Installation

```
git clone https://github.com/FengheTan9/U-Bench.git
cd U-Bench
conda create -n ubench python=3.9 -y  
conda activate ubench  
pip install -r requirements.txt  
```

#### 2. Datasets

Please put the dataset (e.g. CAMUS) or your own dataset as the following architecture:

```
└── U-Bench
    ├── data
        ├── camus
            ├── images
            |   ├── patient0001_2CH_ED.jpg
            │   ├── patient0001_4CH_ES.jpg
            │   ├── ...
            |
            ├── masks
            |   ├── 0
            |   |   ├── patient0001_2CH_ED.jpg
            |   |   ├── patient0001_4CH_ES.jpg
            |   |   ├── ...
            ├── train.txt
            └── val.txt
    ├── dataloader
    ├── models
    ├── utils
    ├── script
    ├── main.py
    └── main_multi3d.py
```

CAMUS is available: [HERE](https://drive.google.com/drive/folders/1Q6zak5W2ydTQ60BBnOkp1Nkr7Pk6-XYG?usp=sharing)

#### 3. Training & Validation

```python
# CAMUS
python main.py --max_epochs 300 --gpu 0 --batch_size 8 --model U_Net --base_dir ./data/camus --dataset_name camus
```

#### 4. In-domain Inference

Checkpoint of U-Net on CAMUS is available [HERE](https://drive.google.com/drive/folders/1Q6zak5W2ydTQ60BBnOkp1Nkr7Pk6-XYG?usp=sharing)

```python
# CAMUS
python main.py --max_epochs 300 --gpu 0 --batch_size 8 --model U_Net --base_dir ./data/camus --dataset_name camus --just_for_test True
```

## Citation

If using this work (**dataset**, **weights**, or **benchmark results**), please cite:

```
@article{tang2025u,
  title={U-Bench: A Comprehensive Understanding of U-Net through 100-Variant Benchmarking},
  author={Tang, Fenghe and Dong, Chengqi and Ma, Wenxin and Xu, Zikang and Zhu, Heqin and Jiang, Zihang and Wang, Rongsheng and Wang, Yuhao and Wu, Chenxu and Zhou, Shaohua Kevin},
  journal={arXiv preprint arXiv:2510.07041},
  year={2025}
}
```